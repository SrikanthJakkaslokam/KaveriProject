export class EncumbranceCertificate {
  propertyNumberType: number;
  peropertyNumberTypeId: any;
  propertyDetails: any;
  propertyDetailsId: any;
}
