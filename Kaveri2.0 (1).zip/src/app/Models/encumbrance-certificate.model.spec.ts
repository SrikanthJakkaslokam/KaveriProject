import { EncumbranceCertificate } from './encumbrance-certificate.model';

describe('EncumbranceCertificate', () => {
  it('should create an instance', () => {
    expect(new EncumbranceCertificate()).toBeTruthy();
  });
});
