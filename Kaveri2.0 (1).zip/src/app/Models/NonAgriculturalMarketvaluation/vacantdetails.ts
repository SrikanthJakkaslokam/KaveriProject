export interface Vacantdetails {
}
